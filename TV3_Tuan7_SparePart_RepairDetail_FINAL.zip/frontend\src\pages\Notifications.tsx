import React, { useState } from "react";
import { Card, Badge, Button, Tabs, Icons } from "../components/ui";
import { mockNotifications } from "../data";

const TYPE_ICON: Record<string, React.ReactNode> = {
  appointment: Icons.calendar,
  repair: Icons.wrench,
  parts: Icons.alertTriangle,
  payment: Icons.creditCard,
};

const TYPE_COLOR: Record<string, string> = {
  appointment: "bg-info-soft text-info",
  repair: "bg-success-soft text-success",
  parts: "bg-warning-soft text-warning",
  payment: "bg-primary-soft text-primary",
};

export default function Notifications() {
  const [filter, setFilter] = useState("all");
  const [notifications, setNotifications] = useState(mockNotifications);

  const filtered = notifications.filter(n => {
    if (filter === "unread") return !n.read;
    if (filter === "read") return n.read;
    return true;
  });

  const markAllRead = () => setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  const markRead = (id: string) => setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Tabs
          tabs={[
            { key: "all", label: "Tất cả", count: notifications.length },
            { key: "unread", label: "Chưa đọc", count: notifications.filter(n => !n.read).length },
            { key: "read", label: "Đã đọc" },
          ]}
          active={filter}
          onChange={setFilter}
        />
        <Button variant="ghost" size="sm" onClick={markAllRead}>Đánh dấu tất cả đã đọc</Button>
      </div>

      <div className="max-w-3xl space-y-2">
        {filtered.length === 0 && (
          <Card className="py-16 flex items-center justify-center text-slate-400">
            <p className="text-sm">Không có thông báo nào</p>
          </Card>
        )}
        {filtered.map(n => (
          <button key={n.id} type="button"
            className={`flex w-full items-start gap-4 rounded-lg border bg-surface p-4 text-left transition-all hover:border-primary/50 ${!n.read ? "border-info/30 bg-info-soft/50" : "border-border"}`}
            onClick={() => markRead(n.id)} aria-label={`${n.read ? "Thông báo đã đọc" : "Đánh dấu đã đọc"}: ${n.title}`}>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${TYPE_COLOR[n.type]}`}>
              {TYPE_ICON[n.type]}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <p className={`font-semibold text-sm ${!n.read ? "text-slate-900" : "text-slate-700"}`}>{n.title}</p>
                {!n.read && <span className="mt-1.5 h-2 w-2 flex-shrink-0 rounded-full bg-info" aria-label="Chưa đọc" />}
              </div>
              <p className="text-sm text-slate-600 mt-0.5">{n.body}</p>
              <p className="text-xs text-slate-400 mt-1">
                {new Date(n.time).toLocaleString("vi-VN")} · KH: {n.customerId}
                {n.appointmentId ? ` · Lịch: ${n.appointmentId}` : ""}
                {n.repairId ? ` · Phiếu SC: ${n.repairId}` : ""}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
